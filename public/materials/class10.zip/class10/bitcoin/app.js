// Coinbase BTC URL: https://api.coinbase.com/v2/prices/BTC-USD/buy
