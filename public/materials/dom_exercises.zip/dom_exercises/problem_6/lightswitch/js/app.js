$(document).ready(function () {

	var lights = 'on';

})
