console.log('This file is responsible for running your JavaScript')
